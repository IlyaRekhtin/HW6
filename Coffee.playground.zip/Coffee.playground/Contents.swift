import UIKit

protocol Coffee {
    var cost: Int {get}
}

class SimpleCoffee: Coffee {
    var cost: Int = 60
}


//MARK: - Decorator
protocol CoffeeDecorator: Coffee {
    var base: Coffee {get}
    init(_ base: Coffee)
}

class Milk: CoffeeDecorator {
    var base: Coffee
    required init(_ base: Coffee) {
        self.base = base
    }
    var cost: Int {
        return base.cost + 20
    }
}

class Sugar: CoffeeDecorator {
    var base: Coffee
    required init(_ base: Coffee) {
        self.base = base
    }
    var cost: Int {
        base.cost + 10
    }
}


let coffee = SimpleCoffee()
let coffeWithMilK = Milk(coffee)
let coffeWithMilkEndSugar = Sugar(coffeWithMilK)
let coffeWithSugar = Sugar(coffee)

print(coffee.cost)
print(coffeWithMilK.cost)
print(coffeWithMilkEndSugar.cost)
print(coffeWithSugar.cost)
